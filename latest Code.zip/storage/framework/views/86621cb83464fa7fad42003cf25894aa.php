<?php
    $label = $attributes['label'];
    $checked = $attributes['checked'];
    $errorClass = '';
?>


<?php unset($attributes['label']); ?>
<?php unset($attributes['checked']); ?>

<?php if($errors->has($attributes['name'])): ?>
    <?php
        $errorClass = 'form-control-danger'
    ?>
<?php endif; ?>

<div class="border-checkbox-section">
    <div class="border-checkbox-group border-checkbox-group-primary">
        <input class="border-checkbox" type="checkbox" id="<?php echo e($id); ?>"
            <?php echo e($attributes->merge(['class' => 'form-control '.$errorClass])); ?> 
            <?php echo e($checked ? 'checked': ''); ?>

        >

        <label class="border-checkbox-label" for="<?php echo e($id); ?>"><?php echo e($label); ?></label>
    </div>
</div>
<?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/components/input-checkbox.blade.php ENDPATH**/ ?>