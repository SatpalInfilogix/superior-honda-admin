

<?php $__env->startSection('content'); ?>
    <div class="pcoded-inner-content">
        
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php if(session('success')): ?>
                                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['message' => ''.e(session('success')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => ''.e(session('success')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                            <?php endif; ?>
                            <?php if(session('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session('import_errors')): ?>
                                <div class="alert alert-danger">
                                    <strong>Errors:</strong>
                                    <ul>
                                        <?php $__currentLoopData = session('import_errors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                Row <?php echo e($index + 1); ?>:
                                                <?php if(isset($error['errors'])): ?>
                                                    <?php $__currentLoopData = $error['errors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        Field: <?php echo e($field); ?> - <?php echo e(is_array($messages) ? implode('; ', $messages) : $messages); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php echo e(implode('; ', $error['errors'])); ?>

                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <div class="card">
                                <div class="card-header">
                                    <h5>Products</h5>

                                    <div class="float-right">
                                        <a href="<?php echo e(route('product-export.csv')); ?>" class="btn btn-primary primary-btn btn-md"><i class="fa fa-download"></i>Export Products</a>
                                        <a href="<?php echo e(url('download-product-sample')); ?>"
                                            class="btn btn-primary primary-btn btn-md"><i class="fa fa-download"></i>Product Sample File
                                        </a>
                                        <div class="file-button btn btn-primary primary-btn">
                                            <form action="<?php echo e(route('products.import')); ?>" method="POST"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                Import CSV
                                                <input type="file" name="file" accept=".csv" class="input-field" />
                                            </form>
                                        </div>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create product')): ?>
                                            <a href="<?php echo e(route('products.create')); ?>"
                                                class="btn btn-primary primary-btn btn-md">Add product
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-block">
                                    <div class="dt-responsive table-responsive">
                                        <form id="productFilterForm" method="GET" action="<?php echo e(route('products.index')); ?>" class="mb-3">
                                            <div class="row mr-0">
                                                <div class="col-md-3">
                                                    <input name="product" id="productSearch" type="text" class="form-control product-autocomplete"
                                                    value="<?php echo e(request('product')); ?>" placeholder="Enter Product Name">
                                                    <div class="autocomplete-items"></div>                                                
                                                </div>
                                                <div class="col-md-3">
                                                    <input type="text" name="product_code" class="form-control" placeholder="Enter Product Code" value="<?php echo e(request('product_code')); ?>">
                                                </div>
                                                <div class="col-md-3">
                                                    <input type="text" name="item_number" class="form-control" placeholder="Enter Item Number" value="<?php echo e(request('item_number')); ?>">
                                                </div>
                                                <div class="col-md-3">
                                                    <button type="submit" class="btn btn-primary primary-btn custom">Filter</button>
                                                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary custom">Reset</a>
                                                </div>
                                            </div>
                                        </form>
                                        <table id="products-list"
                                            class="table table-striped table-bordered nowrap">
                                            <thead>
                                                <tr>
                                                    <th style="width:0px !important;">#</th>
                                                    <th style="width:487.585px !important;">Product Name</th>
                                                    <!-- <th>Barcode</th> -->
                                                    <!-- <th>Manufacture Name</th>
                                                    <th>Vehicle Category</th> -->
                                                    <!-- <th>Brand Name</th> -->
                                                    <th style="width:276.065px !important;">Model Name</th>
                                                    <!-- <th>Variant Name</th>
                                                    <th>Vehicle Type</th> -->
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit product', 'delete product'])): ?>
                                                        <th style="width:200px !important;">Actions</th>
                                                    <?php endif; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($index + 1); ?></td>
                                                        <td><?php echo e($product->product_name); ?></td>
                                                        <!-- <td><?php echo $product->barcode; ?>

                                                            P- <?php echo e($product->product_code. ' '.$product->product_name); ?>

                                                        </td> -->
                                                        <!-- <td><?php echo e($product->manufacture_name); ?></td>
                                                        <td><?php echo e(optional($product->category)->name); ?></td> -->
                                                        <!-- <td><?php echo e(optional($product->brand)->brand_name); ?></td> -->
                                                        <td><?php echo e(optional($product->model)->model_name); ?></td>
                                                        <!-- <td><?php echo e(optional($product->variant)->variant_name); ?></td>
                                                        <td><?php echo e(optional($product->type)->vehicle_type); ?></td> -->
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
                                                            'edit product',
                                                            'delete product',
                                                            ])): ?>
                                                            <td>
                                                                <div class="btn-group btn-group-sm">
                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit product')): ?>
                                                                        <a href="<?php echo e(route('products.edit', $product->id)); ?>"
                                                                            class="btn btn-primary primary-btn waves-effect waves-light mr-2 edit-vehicle-type">
                                                                            <i class="feather icon-edit m-0"></i>
                                                                        </a>
                                                                    <?php endif; ?>

                                                                    <?php if($product->status == 1): ?>
                                                                        <button
                                                                            class="disable-product btn btn-primary primary-btn waves-effect waves-light mr-2"
                                                                            data-id="<?php echo e($product->id); ?>" data-value="enabled">
                                                                            <i class="feather icon-check-circle m-0"></i>
                                                                        </button>
                                                                    <?php else: ?>
                                                                        <button
                                                                            class="disable-product btn btn-primary primary-btn waves-effect waves-light mr-2"
                                                                            data-id="<?php echo e($product->id); ?>" data-value="disabled">
                                                                            <i class="feather icon-slash m-0"></i>
                                                                        </button>
                                                                    <?php endif; ?>

                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete product')): ?>
                                                                        <button data-source="product"
                                                                            data-endpoint="<?php echo e(route('products.destroy', $product->id)); ?>"
                                                                            class="delete-btn primary-btn btn btn-danger waves-effect waves-light">
                                                                            <i class="feather icon-trash m-0"></i>
                                                                        </button>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal5609eec52f8d452951cdd2468aad14ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5609eec52f8d452951cdd2468aad14ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.include-plugins','data' => ['dataTable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('include-plugins'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['dataTable' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $attributes = $__attributesOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $component = $__componentOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__componentOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>
    <script>
        document.getElementById('productFilterForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission
            const form = event.target;
            const formData = new FormData(form);
            const queryParams = new URLSearchParams();
        
            formData.forEach((value, key) => {
                if (value.trim() !== '') {
                    queryParams.append(key, value);
                }
            });
        
            window.location.href = form.action + '?' + queryParams.toString();
        });
        $(document).ready(function () {
            $('body').on('input', '.product-autocomplete', function () {
                var input = $(this).val().trim();
                var autocompleteContainer = $(this).siblings('.autocomplete-items');

                $.ajax({
                    type: 'GET',
                    url: '<?php echo e(route('product.autocomplete')); ?>',
                    data: { input: input },
                    success: function (response) {
                        autocompleteContainer.empty();
                        if (response.length > 0) {
                            $.each(response, function (key, value) {
                                var autocompleteItem = '<div class="autocomplete-item" data-id="' + value.id + '">' + value.product_name + '</div>';
                                autocompleteContainer.append(autocompleteItem);
                            });
                            autocompleteContainer.show();
                        } else {
                            autocompleteContainer.hide();
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('Autocomplete AJAX error:', status, error);
                    }
                });
            });

            $('body').on('click', '.autocomplete-item', function() {
                var productName = $(this).text();
                var productId = $(this).data('id');
                $('#productSearch').val(productName);
                $(this).closest('.autocomplete-items').empty().hide();
            });
        });

        $(function() {
            $('[name="file"]').change(function() {
                $(this).parents('form').submit();
            });

            $('#products-list').DataTable();

                $(document).on('click', '.disable-product', function() {
                    var id = $(this).data('id');
                    var value = $(this).data('value');
                    swal({
                        title: "Are you sure?",
                        text: `You really want to ${value == 'enabled' ? 'disabled' : 'enabled'} ?`,
                        type: "warning",
                        showCancelButton: true,
                        closeOnConfirm: false,
                    }, function(isConfirm) {
                        if (isConfirm) {
                            $.ajax({
                                url: '<?php echo e(route("disable-product")); ?>',
                                method: 'post',
                                data: {
                                    id: id,
                                    disable_product: value,
                                    _token: '<?php echo e(csrf_token()); ?>'
                                },
                                success: function(response) {
                                    if(response.success){
                                        swal({
                                            title: "Success!",
                                            text: response.message,
                                            type: "success",
                                            showConfirmButton: false
                                        }) 

                                        setTimeout(() => {
                                            location.reload();
                                        }, 2000);
                                    }
                                }
                            })
                        }
                    });
                })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/products/index.blade.php ENDPATH**/ ?>