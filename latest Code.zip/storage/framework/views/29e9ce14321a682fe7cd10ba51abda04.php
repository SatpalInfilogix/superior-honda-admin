

<?php $__env->startSection('content'); ?>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">

                    <div class="row">
                        <div class="col-sm-12">
                            <?php if(session('success')): ?>
                                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['message' => ''.e(session('success')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => ''.e(session('success')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                            <?php endif; ?>
                            <?php if(session('error')): ?>
                                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['message' => ''.e(session('error')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => ''.e(session('error')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                            <?php endif; ?>

                            <?php if(session('import_errors')): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = session('import_errors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <?php $__currentLoopData = $error['errors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <strong>Row <?php echo e($loop->parent->index + 1); ?>:</strong>
                                                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($message); ?><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <div class="card">
                                <div class="card-header">
                                    <h5>Customer Inquiry</h5>
                                    <div class="float-right">
                                        <select class="form-control" name="branch" id="branch">
                                            
                                            <?php if(!empty($branches)): ?>
                                                <?php
                                                    $branch_selected = !empty($selected_branch_id) ? $selected_branch_id : Auth::user()->branch_id;
                                                ?>
                                                <option value="all" <?php echo e('all' == $branch_selected ? 'selected' : ''); ?>>All Branches</option>
                                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($branch->id); ?>" <?php echo e($branch->id == $branch_selected ? 'selected' : ''); ?>><?php echo e($branch->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="card-block">
                                    <div class="dt-responsive table-responsive">
                                        <form id="inquiryFilterForm" method="GET" action="<?php echo e(route(request()->route()->getName(), $selected_branch_id)); ?>" class="mb-3">
                                            <div class="row mr-0">
                                                <div class="col-md-3">
                                                    <input type="text" name="mobile" class="form-control" placeholder="Mobile Number" value="<?php echo e(request('mobile')); ?>">
                                                </div>
                                                <div class="col-md-3">
                                                    <select name="status"  class="form-control">
                                                        <option value="" selected>Select Status</option>
                                                        <option value="pending" <?php if(request('status') == 'pending'): echo 'selected'; endif; ?>>Pending</option>
                                                        <option value="in_process" <?php if(request('status') == 'in_process'): echo 'selected'; endif; ?>>Processing</option>
                                                        <option value="closed" <?php if(request('status') == 'closed'): echo 'selected'; endif; ?>>Closed</option>
                                                        <option value="failed" <?php if(request('failed') == 'cancelled'): echo 'selected'; endif; ?>>Cancelled</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-3">
                                                    <input type="date" name="date" class="form-control" value="<?php echo e(request('date')); ?>">
                                                </div>
                                                <div class="col-md-3">
                                                    <button type="submit" class="btn btn-primary primary-btn custom">Filter</button>
                                                    <a href="<?php echo e(route(request()->route()->getName(),$selected_branch_id)); ?>" class="btn btn-secondary custom">Reset</a>
                                                </div>
                                            </div>
                                        </form>
                                        <table id="customer-inquiry" class="table table-striped table-bordered nowrap">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Customer Name</th>
                                                    <th>Inquiry Status</th>
                                                    <th>Date</th>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit customer inquiry', 'delete customer inquiry'])): ?>
                                                    <th>Actions</th>
                                                    <?php endif; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(!empty($final_customer_enquiry_data)): ?>
                                                    <?php $__currentLoopData = $final_customer_enquiry_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer_inquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($key + 1); ?></td>
                                                            <td><?php echo e(ucfirst($customer_inquiry->customer_name)); ?></td>
                                                            <?php if($customer_inquiry->inquiry_status == 'pending'): ?>
                                                            <td style="color:blue"><?php echo e(ucfirst($customer_inquiry->inquiry_status)); ?></td>
                                                            <?php elseif($customer_inquiry->inquiry_status == 'in_process'): ?>
                                                            <td style="color:#ff6a00">In Process</td>
                                                            <?php elseif($customer_inquiry->inquiry_status == 'closed'): ?>
                                                            <td style="color:green"><?php echo e(ucfirst($customer_inquiry->inquiry_status)); ?></td>
                                                            <?php elseif($customer_inquiry->inquiry_status == 'failed'): ?>
                                                            <td style="color:red"><?php echo e(ucfirst($customer_inquiry->inquiry_status)); ?></td>
                                                            <?php endif; ?>
                                                            <td><?php echo e(date('d-m-Y h:i a', strtotime($customer_inquiry->inquiry_created_at))); ?></td>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit customer inquiry', 'delete customer inquiry'])): ?>
                                                            <td>
                                                                <div class="btn-group btn-group-sm">
                                                                    <?php if(Auth::user()->can('edit customer inquiry')): ?>
                                                                        <a href="<?php echo e(route('customer-inquiry.edit', $customer_inquiry->id)); ?>"
                                                                            class="btn btn-primary primary-btn waves-effect waves-light mr-2">
                                                                            <i class="feather icon-edit m-0"></i>
                                                                        </a>
                                                                    <?php endif; ?>

                                                                    <?php if($customer_inquiry->status == 'active'): ?>
                                                                        <button
                                                                            class="disable-customer-inquiry btn btn-primary primary-btn waves-effect waves-light mr-2"
                                                                            data-id="<?php echo e($customer_inquiry->id); ?>" data-value="enabled">
                                                                            <i class="feather icon-check-circle m-0"></i>
                                                                        </button>
                                                                    <?php else: ?>
                                                                        <button
                                                                            class="disable-customer-inquiry btn btn-primary primary-btn waves-effect waves-light mr-2"
                                                                            data-id="<?php echo e($customer_inquiry->id); ?>" data-value="disabled">
                                                                            <i class="feather icon-slash m-0"></i>
                                                                        </button>
                                                                    <?php endif; ?>
                                                                    <?php if(Auth::user()->can('delete customer inquiry')): ?>
                                                                        <button data-source="Customer Inquiry" data-endpoint="<?php echo e(route('customer-inquiry.destroy', $customer_inquiry->id)); ?>"
                                                                            class="delete-btn primary-btn btn btn-danger waves-effect waves-light">
                                                                            <i class="feather icon-trash m-0"></i>
                                                                        </button>
                                                                    <?php endif; ?> 
                                                                </div>
                                                            </td>
                                                            <?php endif; ?>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal5609eec52f8d452951cdd2468aad14ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5609eec52f8d452951cdd2468aad14ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.include-plugins','data' => ['dataTable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('include-plugins'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['dataTable' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $attributes = $__attributesOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $component = $__componentOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__componentOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>

    <script>
        $(function() {
            document.getElementById('inquiryFilterForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission
            const form = event.target;
            const formData = new FormData(form);
            const queryParams = new URLSearchParams();
        
            formData.forEach((value, key) => {
                if (value.trim() !== '') {
                    queryParams.append(key, value);
                }
            });
        
                window.location.href = form.action + '?' + queryParams.toString();
            });


            $('#customer-inquiry').DataTable();

            $(document).on('click', '.disable-customer-inquiry', function() {
                var id = $(this).data('id');
                var value = $(this).data('value');
                swal({
                    title: "Are you sure?",
                    text: `You really want to ${value == 'enabled' ? 'disabled' : 'enabled'} ?`,
                    type: "warning",
                    showCancelButton: true,
                    closeOnConfirm: false,
                }, function(isConfirm) {
                    if (isConfirm) {
                        $.ajax({
                            url: '<?php echo e(route("disable-customer-inquiry")); ?>',
                            method: 'post',
                            data: {
                                id: id,
                                disable_customer_inquiry: value,
                                _token: '<?php echo e(csrf_token()); ?>'
                            },
                            success: function(response) {
                                if(response.success){
                                    swal({
                                        title: "Success!",
                                        text: response.message,
                                        type: "success",
                                        showConfirmButton: false
                                    }) 

                                    setTimeout(() => {
                                        location.reload();
                                    }, 2000);
                                }
                            }
                        })
                    }
                });
            })
        });

        $(document).ready(function () {
            $("#branch").change(function () {
                var branchId = $(this).val();
                if (branchId) {
                    window.location.href = "/customer-inquiry/branch/" + branchId;
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/customer_inquiry/index.blade.php ENDPATH**/ ?>