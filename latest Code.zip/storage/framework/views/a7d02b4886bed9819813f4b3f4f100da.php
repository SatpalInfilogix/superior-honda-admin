

<?php $__env->startSection('content'); ?>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php if(session('success')): ?>
                                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['message' => ''.e(session('success')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => ''.e(session('success')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                            <?php endif; ?>
                            <?php if(session('import_errors')): ?>
                                <div class="alert alert-danger">
                                    <strong>Errors:</strong>
                                    <ul>
                                        <?php $__currentLoopData = session('import_errors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                Row <?php echo e($index + 1); ?>:
                                                <?php if(isset($error['errors'])): ?>
                                                    <?php $__currentLoopData = $error['errors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        Field: <?php echo e($field); ?> - <?php echo e(is_array($messages) ? implode('; ', $messages) : $messages); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php echo e(implode('; ', $error['errors'])); ?>

                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        
                            <div class="card">
                                <div class="card-header">
                                    <h5>Vehicles</h5>

                                    <div class="float-right">
                                        <a href="<?php echo e(route('export.csv')); ?>" class="btn btn-primary primary-btn btn-md"><i class="fa fa-download"></i>Download Vehicle Configuration</a>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create vehicle')): ?>
                                            <a href="<?php echo e(url('download-vehicle-sample')); ?>"
                                                class="btn btn-primary primary-btn btn-md"><i class="fa fa-download"></i>Vehicle Sample File
                                            </a>
                                            <div class="d-inline-block">
                                                <form id="importForm" action="<?php echo e(route('vehicle.import')); ?>" method="POST" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <label for="fileInput" class="btn btn-primary primary-btn btn-md mb-0">
                                                        Import CSV
                                                        <input type="file" id="fileInput" name="file" accept=".csv" style="display:none;">
                                                    </label>
                                                </form>
                                            </div>
                                            <a href="<?php echo e(route('vehicles.create')); ?>"
                                                class="btn btn-primary primary-btn btn-md">Add Vehicle
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-block">
                                    <div class="dt-responsive table-responsive">
                                        <table id="vehicles-list"
                                            class="table table-striped table-bordered nowrap">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Customer</th>
                                                    <th>Category</th>
                                                    <th>Brand</th>
                                                    <th>Model</th>
                                                    <th>Variant</th>
                                                    <th>Type</th>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit vehicle', 'delete vehicle'])): ?>
                                                        <th>Actions</th>
                                                    <?php endif; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($index + 1); ?></td>
                                                        <td><?php echo e($vehicle->customer->first_name.' '.$vehicle->customer->last_name); ?></td>
                                                        <td><?php echo e($vehicle->category->name); ?></td>
                                                        <td><?php echo e(optional($vehicle->brand)->brand_name); ?></td>
                                                        <td><?php echo e(optional($vehicle->model)->model_name); ?></td>
                                                        <td><?php echo e(optional($vehicle->variant)->variant_name); ?></td>
                                                        <td><?php echo e(optional($vehicle->type)->vehicle_type); ?></td>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
                                                            'edit vehicle',
                                                            'delete vehicle',
                                                            ])): ?>
                                                            <td>
                                                                <div class="btn-group btn-group-sm">
                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit vehicle')): ?>
                                                                        <a href="<?php echo e(route('vehicles.edit', $vehicle->id)); ?>"
                                                                            class="btn btn-primary primary-btn waves-effect waves-light mr-2 edit-vehicle-type">
                                                                            <i class="feather icon-edit m-0"></i>
                                                                        </a>
                                                                    <?php endif; ?>

                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete vehicle')): ?>
                                                                        <button data-source="product"
                                                                            data-endpoint="<?php echo e(route('vehicles.destroy', $vehicle->id)); ?>"
                                                                            class="delete-btn primary-btn btn btn-danger waves-effect waves-light">
                                                                            <i class="feather icon-trash m-0"></i>
                                                                        </button>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal5609eec52f8d452951cdd2468aad14ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5609eec52f8d452951cdd2468aad14ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.include-plugins','data' => ['dataTable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('include-plugins'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['dataTable' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $attributes = $__attributesOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $component = $__componentOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__componentOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>
    <script>
        $(function() {
            $('#vehicles-list').DataTable();
        })

        $(document).ready(function() {
            $('#importButton').on('click', function() {
                $('#fileInput').click();
            });

            $('#fileInput').on('change', function(event) {
                var file = $(this).prop('files')[0];
                if (file && file.type === 'text/csv') {
                    $('#importForm').submit();
                } else {
                    alert('Please select a valid CSV file.');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/vehicles/index.blade.php ENDPATH**/ ?>