<?php if(isset($attributes['label'])): ?>
<label for="<?php echo e($attributes['name']); ?>"><?php echo e($attributes['label']); ?>

<?php endif; ?>
<?php if(isset($attributes['required'])): ?>
 <span style="color: red;">*</span>
<?php endif; ?>
</label>
<?php unset($attributes['label']); ?>

<?php
    $errorClass = '';
?>

<?php if($errors->has($attributes['name'])): ?>
    <?php
        $errorClass = 'form-control-danger'
    ?>
<?php endif; ?>

<input type="text" id="<?php echo e($attributes['name']); ?>" autocomplete="false"
    <?php echo e($attributes->merge(['class' => 'form-control '.$errorClass])); ?> 
/>

<?php $__errorArgs = [$attributes['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger f-12"><?php echo e($message); ?></span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/components/input-text.blade.php ENDPATH**/ ?>