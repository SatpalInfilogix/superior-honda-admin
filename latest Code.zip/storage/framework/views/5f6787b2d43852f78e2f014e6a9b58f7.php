

<?php $__env->startSection('content'); ?>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php if(session('success')): ?>
                                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['message' => ''.e(session('success')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => ''.e(session('success')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                            <?php endif; ?>

                            <div class="card">
                                <div class="card-header">
                                    <h5>Roles & Permissions</h5>
                                </div>
                                <div class="card-block">
                                    <div class="roles-and-permissions">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="accordion-msg b-none waves-effect waves-light"><?php echo e($role->name); ?></a>
                                            <form action="<?php echo e(route('roles-and-permissions.store')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="role_id" value="<?php echo e($role->id); ?>">
                                                <div class="accordion-desc p-0 b-default">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Module Name</th>
                                                                <th>View</th>
                                                                <th>Add</th>
                                                                <th>Update</th>
                                                                <th>Delete</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <th scope="row"><?php echo e($module->name); ?></th>
                                                                    <td>
                                                                        <?php if (isset($component)) { $__componentOriginal5bfa0e8b5058831b38a4c368c29eff42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-checkbox','data' => ['name' => 'permissions[]','id' => ''.e($role->id . 'view_' . $module->slug).'','value' => ''.e('view ' . $module->slug).'','checked' => ''.e($role->permissions->contains('name', 'view ' . $module->slug)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'permissions[]','id' => ''.e($role->id . 'view_' . $module->slug).'','value' => ''.e('view ' . $module->slug).'','checked' => ''.e($role->permissions->contains('name', 'view ' . $module->slug)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42)): ?>
<?php $attributes = $__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42; ?>
<?php unset($__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bfa0e8b5058831b38a4c368c29eff42)): ?>
<?php $component = $__componentOriginal5bfa0e8b5058831b38a4c368c29eff42; ?>
<?php unset($__componentOriginal5bfa0e8b5058831b38a4c368c29eff42); ?>
<?php endif; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php if (isset($component)) { $__componentOriginal5bfa0e8b5058831b38a4c368c29eff42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-checkbox','data' => ['name' => 'permissions[]','id' => ''.e($role->id . 'create_' . $module->slug).'','value' => ''.e('create ' . $module->slug).'','checked' => ''.e($role->permissions->contains('name', 'create ' . $module->slug)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'permissions[]','id' => ''.e($role->id . 'create_' . $module->slug).'','value' => ''.e('create ' . $module->slug).'','checked' => ''.e($role->permissions->contains('name', 'create ' . $module->slug)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42)): ?>
<?php $attributes = $__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42; ?>
<?php unset($__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bfa0e8b5058831b38a4c368c29eff42)): ?>
<?php $component = $__componentOriginal5bfa0e8b5058831b38a4c368c29eff42; ?>
<?php unset($__componentOriginal5bfa0e8b5058831b38a4c368c29eff42); ?>
<?php endif; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php if (isset($component)) { $__componentOriginal5bfa0e8b5058831b38a4c368c29eff42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-checkbox','data' => ['name' => 'permissions[]','id' => ''.e($role->id . 'edit_' . $module->slug).'','value' => ''.e('edit ' . $module->slug).'','checked' => ''.e($role->permissions->contains('name', 'edit ' . $module->slug)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'permissions[]','id' => ''.e($role->id . 'edit_' . $module->slug).'','value' => ''.e('edit ' . $module->slug).'','checked' => ''.e($role->permissions->contains('name', 'edit ' . $module->slug)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42)): ?>
<?php $attributes = $__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42; ?>
<?php unset($__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bfa0e8b5058831b38a4c368c29eff42)): ?>
<?php $component = $__componentOriginal5bfa0e8b5058831b38a4c368c29eff42; ?>
<?php unset($__componentOriginal5bfa0e8b5058831b38a4c368c29eff42); ?>
<?php endif; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php if (isset($component)) { $__componentOriginal5bfa0e8b5058831b38a4c368c29eff42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-checkbox','data' => ['name' => 'permissions[]','id' => ''.e($role->id . 'delete_' . $module->slug).'','value' => ''.e('delete ' . $module->slug).'','checked' => ''.e($role->permissions->contains('name', 'delete ' . $module->slug)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'permissions[]','id' => ''.e($role->id . 'delete_' . $module->slug).'','value' => ''.e('delete ' . $module->slug).'','checked' => ''.e($role->permissions->contains('name', 'delete ' . $module->slug)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42)): ?>
<?php $attributes = $__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42; ?>
<?php unset($__attributesOriginal5bfa0e8b5058831b38a4c368c29eff42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bfa0e8b5058831b38a4c368c29eff42)): ?>
<?php $component = $__componentOriginal5bfa0e8b5058831b38a4c368c29eff42; ?>
<?php unset($__componentOriginal5bfa0e8b5058831b38a4c368c29eff42); ?>
<?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>

                                                <button type="submit" class="btn btn-primary primary-btn mt-2">Save</button>
                                            </form>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/notification.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/bootstrap-growl.min.js')); ?>"></script>

    <script>
        $(function() {
            var icons = {
                header: "fas fa-up-arrow",
                activeHeader: "fas fa-down-arrow"
            };

            $(".roles-and-permissions").accordion({
                heightStyle: "content",
                icons: icons
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/roles-and-permissions/index.blade.php ENDPATH**/ ?>