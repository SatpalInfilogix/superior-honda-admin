

<?php $__env->startSection('content'); ?>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">

                    <div class="row">
                        <div class="col-sm-12">
                            <div id="success-message" class="alert-success text-success f-12" style="display: none;"></div>

                            <?php if(session('success')): ?>
                                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['message' => ''.e(session('success')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => ''.e(session('success')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                            <?php endif; ?>
                            <?php if(session('error')): ?>
                                <?php $__currentLoopData = session('error'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorKey => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'error','message' => ''.e($value).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error','message' => ''.e($value).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
                            <div class="card">
                                <div class="card-header">
                                    <h5>Orders</h5>
                                    <div class="float-right">
                                        
                                    </div>
                                </div>
                                <div class="card-block">
                                    <div class="dt-responsive table-responsive">
                                        <form id="orderFilterForm" method="GET" action="<?php echo e(route('orders.index')); ?>" class="mb-3">
                                            <div class="row mr-0">
                                                <div class="col-md-2">
                                                    <input type="text" name="order_id" class="form-control" placeholder="Order ID" value="<?php echo e(request('order_id')); ?>">
                                                </div>
                                                <div class="col-md-2">
                                                    <input type="text" name="mobile" class="form-control" placeholder="Mobile Number" value="<?php echo e(request('mobile')); ?>">
                                                </div>
                                                <div class="col-md-2">
                                                    <select name="order_status"  class="form-control">
                                                        <option value="" selected>Select Status</option>
                                                        <option value="pending" <?php if(request('order_status') == 'pending'): echo 'selected'; endif; ?>>Pending</option>
                                                        <option value="processing" <?php if(request('order_status') == 'processing'): echo 'selected'; endif; ?>>Processing</option>
                                                        <option value="completed" <?php if(request('order_status') == 'completed'): echo 'selected'; endif; ?>>Completed</option>
                                                        <option value="cancelled" <?php if(request('order_status') == 'cancelled'): echo 'selected'; endif; ?>>Cancelled</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-3">
                                                    <input type="date" name="date" class="form-control" value="<?php echo e(request('date')); ?>">
                                                </div>
                                                <div class="col-md-3">
                                                    <button type="submit" class="btn btn-primary primary-btn custom">Filter</button>
                                                    <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-secondary custom">Reset</a>
                                                </div>
                                            </div>
                                        </form>
                                        <table id="order-list" class="table table-striped table-bordered nowrap">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Phone Number</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($key + 1); ?></td>
                                                        <td><?php echo e(optional($order['billingAddress'])->first_name .' '. optional($order['billingAddress'])->last_name); ?></td>
                                                        <td><?php echo e($order['email']); ?></td>
                                                        <td><?php echo e($order['phone_number']); ?></td>
                                                        <td>
                                                            <select name="status" class="btn btn-secondary dropdown-toggle status-dropdown" data-id="<?php echo e($order['id']); ?>">
                                                                <option value="pending" <?php echo e($order['status'] == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                                                <option value="processing" <?php echo e($order['status'] == 'processing' ? 'selected' : ''); ?>>Processing</option>
                                                                <option value="completed" <?php echo e($order['status'] == 'completed' ? 'selected' : ''); ?>>Completed</option>
                                                                <option value="cancelled" <?php echo e($order['status'] == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <div class="btn-group btn-group-sm">
                                                                <button type="button"
                                                                    class="btn btn-primary primary-btn waves-effect waves-light mr-2"
                                                                    data-toggle="modal"
                                                                    data-target="#wishlistModal<?php echo e($key); ?>">
                                                                    <i class="feather icon-eye m-0"></i>
                                                                </button>
                                                            </div>
                                                            
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal5609eec52f8d452951cdd2468aad14ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5609eec52f8d452951cdd2468aad14ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.include-plugins','data' => ['dataTable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('include-plugins'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['dataTable' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $attributes = $__attributesOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $component = $__componentOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__componentOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
            $address1 = $order->billingAddress;
            $address2 = $order->shippingAddress;
        ?>
        <div class="modal fade" id="wishlistModal<?php echo e($key); ?>" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="width: 148%">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Order Details</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <p><h4>Billing Address:</h4>
                                    <?php echo e($address1->first_name .' '.$address1->last_name); ?> <br>
                                    <?php echo e($address1->address); ?>,<br>
                                    <?php echo e($address1->city); ?>,<?php echo e(optional($address1)->state_name); ?>,
                                    <?php echo e(optional($address1)->country_name); ?>

                                </p>
                            </div>
                            <div class="col-sm-6">
                                <p><h4>Shipping Address:</h4>
                                    <?php echo e($address2->first_name.' '.$address2->last_name); ?> <br>
                                    <?php echo e($address2->address); ?>,<br>
                                    <?php echo e($address1->city); ?>, <?php echo e(optional($address2)->state_name); ?>

                                    <?php echo e(optional($address2)->country_name); ?>

                                </p>
                            </div>
                        </div>
                        <table class="table">
                            <thead>
                                <tr style="line-height: 1%;"> 
                                    <th>#</th>
                                    <th>Product Name</th>
                                    <th>Product code</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $cartProducts = json_decode($order['cart_items']);
                                ?>
                                <?php if(count($cartProducts->products) > 0): ?>
                                    <?php $__currentLoopData = $cartProducts->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="line-height: 1%;">
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($cart->name); ?></td>
                                            <td><?php echo e($cart->product_code); ?></td>
                                            <td><?php echo e($cart->quantity); ?></td>
                                            <td><?php echo e('$'.number_format($cart->price, 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?> 
                                    <tr>
                                        <td colspan="4" class="text-center">Order is empty</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col-sm-6"></div>
                            <div class="col-sm-6" style="text-align: right">
                                NonTax Total: <?php echo e($cartProducts->formatted_sub_total); ?><br>
                                Discount %: <?php echo e(optional($cartProducts->applied_coupons)['discount_amount']); ?><br>
                                Sub-Total : <?php echo e($cartProducts->formatted_grand_total); ?><br>
                                Tax (18%) : <?php echo e(number_format($cartProducts->grand_total * 0.18, 2)); ?> <br>
                                Total: <?php echo e(number_format($cartProducts->grand_total + ($cartProducts->grand_total * 0.18), 2)); ?>

                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script>
        document.getElementById('orderFilterForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission
            const form = event.target;
            const formData = new FormData(form);
            const queryParams = new URLSearchParams();
        
            formData.forEach((value, key) => {
                if (value.trim() !== '') {
                    queryParams.append(key, value);
                }
            });
        
            window.location.href = form.action + '?' + queryParams.toString();
        });
        $(function() {
            $('#order-list').DataTable();
        })

        $(document).ready(function () {
            $('.status-dropdown').change(function () {
                var status = $(this).val();
                var orderId = $(this).data('id');
                $.ajax({
                    url: '<?php echo e(route("update-status")); ?>',
                    method: 'POST',
                    data: {
                        '_token': '<?php echo e(csrf_token()); ?>',
                        status: status,
                        orderId: orderId
                    },
                    success: function (response) {
                        if(response.success){
                            $('#success-message').html(response.message);
                            $('#success-message').show();
                            setTimeout(function() {
                                $('#success-message').fadeOut('slow');
                            }, 3000);
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error(error);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/orders/index.blade.php ENDPATH**/ ?>