<!DOCTYPE html>
<html lang="en">

<head>
    <title>Superior Honda</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/waves.min.css')); ?>" media="all">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/feather.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome-n.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/sweetalert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datepicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/chosen.min.css')); ?>">
    <!-- <link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet" /> -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/toastr.min.css')); ?>"/>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sweetalert.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('head'); ?>

    <style>
        .chosen-container-multi .chosen-choices li.search-field input[type=text]{
            height: 32px !important;
        }
    </style>
</head>
<?php 
$logo_url= DB::table('settings')->where('key','logo')->first();
if($logo_url)
{$logo_url = $logo_url->value;}
else{
    $logo_url = '';
}
?>
<body>
    <div class="loader-bg">
        <div class="loader-bar"></div>
    </div>

    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">

            <nav class="navbar header-navbar pcoded-header">
                <div class="navbar-wrapper">
                    <div class="navbar-logo">
                        <a href="<?php echo e(route('dashboard.index')); ?>">
                        <?php if($logo_url): ?> 
                        <img class="main__logo--img" src="<?php echo e(env('APP_URL')); ?>/<?php echo e($logo_url); ?>"/>  
                        <?php else: ?>
                            Superior Honda
                        <?php endif; ?>
                        </a>
                        <a class="mobile-menu" id="mobile-collapse" href="#!">
                            <i class="feather icon-menu icon-toggle-right"></i>
                        </a>
                        <a class="mobile-options waves-effect waves-light">
                            <i class="feather icon-more-horizontal"></i>
                        </a>
                    </div>
                    <div class="navbar-container container-fluid">
                        <ul class="nav-right">
                            <li class="user-profile header-notification">
                                <div class="dropdown-primary dropdown">
                                    <div class="dropdown-toggle" data-toggle="dropdown">
                                        <?php if(!Auth::user()->profile_picture): ?>
                                        <img src="<?php echo e(asset('assets/images/user-default.png')); ?>" class="img-radius"
                                            alt="<?php echo e(Auth::user()->first_name); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset(Auth::user()->profile_picture )); ?>" class="img-radius"
                                                alt="<?php echo e(Auth::user()->first_name); ?>">
                                        <?php endif; ?>
                                        <span><?php echo e(Auth::user()->first_name); ?></span>
                                        <i class="feather icon-chevron-down"></i>
                                    </div>
                                    <ul class="show-notification profile-notification dropdown-menu"
                                        data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                                        <li>
                                            <a href="<?php echo e(route('settings.index')); ?>">
                                                <i class="feather icon-settings"></i> Settings
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('profile.index')); ?>">
                                                <i class="feather icon-user"></i> Profile
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('logout')); ?>">
                                                <i class="feather icon-log-out"></i> Logout
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                    <?php echo $__env->make('layouts.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="pcoded-content">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>

                    <div id="styleSelector">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/waves.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pcoded.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vertical-layout.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/script.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/ckeditor.js')); ?>"></script>
    <!-- <script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script> -->
    <script src="<?php echo e(asset('assets/js/chosen.jquery.min.js')); ?>"></script>
    <!-- <script src="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.jquery.min.js"></script> -->
    
    <?php echo $__env->yieldContent('script'); ?>

    <script>
        $(function() {            
            $('.delete-btn').click(function() {
                let source = $(this).data('source');
                let deleteApiEndpoint = $(this).data('endpoint');

                swal({
                    title: "Are you sure?",
                    text: `You really want to remove this ${source}?`,
                    type: "warning",
                    showCancelButton: true,
                    closeOnConfirm: false,
                }, function(isConfirm) {
                    if (isConfirm) {
                        $.ajax({
                            url: deleteApiEndpoint,
                            method: 'DELETE',
                            data: {
                                '_token': '<?php echo e(csrf_token()); ?>'
                            },
                            success: function(response) {
                                if(response.success){
                                    swal({
                                        title: "Success!",
                                        text: response.message,
                                        type: "success",
                                        showConfirmButton: false
                                    }) 

                                    setTimeout(() => {
                                        location.reload();
                                    }, 2000);
                                }
                            }
                        })
                    }
                });
            })
        })
    </script>

    <script>
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "toast-bottom-right",
            "timeOut": "3000",
        };

        <?php if(session('success')): ?>
            toastr.success('<?php echo e(session('success')); ?>');
        <?php elseif(session('error')): ?>
            toastr.error('<?php echo e(session('error')); ?>');
        <?php elseif(session('info')): ?>
            toastr.info('<?php echo e(session('info')); ?>');
        <?php elseif(session('warning')): ?>
            toastr.warning('<?php echo e(session('warning')); ?>');
        <?php endif; ?>
    </script>

    <script>
        $(document).ready(function(){
            $(".chosen-select").on("change", function() {
                var selectedValues = $(this).val();
                var id = $(this).attr('id');

                if (selectedValues && selectedValues.includes("select_all")) {
                    $("#" + id)
                        .find("option:not([value='select_all'])")
                        .prop("selected", true);

                    $("#" + id).find("option[value='select_all']").prop("selected", false);

                    $("#" + id).trigger("chosen:updated");
                }
            });
        })
    </script>


</html>
<?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/layouts/app.blade.php ENDPATH**/ ?>