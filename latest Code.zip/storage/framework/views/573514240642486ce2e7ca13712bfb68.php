

<?php $__env->startSection('content'); ?>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">

                    <div class="row">
                        <div class="col-sm-12">
                            <?php if(session('success')): ?>
                                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['message' => ''.e(session('success')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => ''.e(session('success')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                            <?php endif; ?>

                            <?php if(session('error')): ?>
                            <?php
                                $errorMessages = [];
                        
                                foreach (session('error') as $error) {
                                    foreach ($error as $value) {
                                        $errorMessages[] = $value;
                                    }
                                }
                        
                                $combinedErrors = implode('<br>', $errorMessages); 
                            ?>
                        
                            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'error','message' => ''.$combinedErrors.'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error','message' => ''.$combinedErrors.'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                        <?php endif; ?>

                            <div class="card">
                                <div class="card-header">
                                    <h5>User Management</h5>
                                    <div class="float-right">
                                        <a href="<?php echo e(url('download-user-sample')); ?>"
                                            class="btn btn-primary primary-btn btn-md"><i class="fa fa-download"></i>User Sample File
                                        </a>
                                        <div class="file-button btn btn-primary primary-btn">
                                            <form action="<?php echo e(route('users.import')); ?>" method="POST"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                Import CSV
                                                <input type="file" name="file" accept=".csv" class="input-field" />
                                            </form>
                                        </div>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create user')): ?>
                                            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary primary-btn btn-md">Add
                                                User</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-block">
                                    <div class="dt-responsive table-responsive">
                                        <table id="users-list" class="table table-striped table-bordered nowrap">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                    <th>Designation </th>
                                                    <th>Role</th>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit user', 'delete user'])): ?>
                                                        <th>Actions</th>
                                                    <?php endif; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($key + 1); ?></td>
                                                        <td><?php echo e($user->first_name . $user->last_names); ?></td>
                                                        <td><?php echo e($user->designation); ?></td>
                                                        <td> 
                                                            <?php if($user->roles->isNotEmpty()): ?>
                                                            <?php echo e($user->roles->pluck('name')[0]); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit user', 'delete user'])): ?>
                                                            <td>
                                                                <div class="btn-group btn-group-sm">
                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit user')): ?>
                                                                        <a href="<?php echo e(route('users.edit', $user->id)); ?>"
                                                                            class="btn btn-primary primary-btn waves-effect waves-light mr-2">
                                                                            <i class="feather icon-edit m-0"></i>
                                                                        </a>
                                                                    <?php endif; ?>

                                                                    <?php if($user->status == 'Active'): ?>
                                                                        <button
                                                                            class="disable-user btn btn-primary primary-btn waves-effect waves-light mr-2"
                                                                            data-id="<?php echo e($user->id); ?>" data-value="enabled">
                                                                            <i class="feather icon-check-circle m-0"></i>
                                                                        </button>
                                                                    <?php else: ?>
                                                                        <button
                                                                            class="disable-user btn btn-primary primary-btn waves-effect waves-light mr-2"
                                                                            data-id="<?php echo e($user->id); ?>" data-value="disabled">
                                                                            <i class="feather icon-slash m-0"></i>
                                                                        </button>
                                                                    <?php endif; ?>
                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete user')): ?>
                                                                        <button data-source="User"
                                                                            data-endpoint="<?php echo e(route('users.destroy', $user->id)); ?>"
                                                                            class="delete-btn primary-btn btn btn-danger waves-effect waves-light">
                                                                            <i class="feather icon-trash m-0"></i>
                                                                        </button>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal5609eec52f8d452951cdd2468aad14ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5609eec52f8d452951cdd2468aad14ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.include-plugins','data' => ['dataTable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('include-plugins'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['dataTable' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $attributes = $__attributesOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $component = $__componentOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__componentOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>

    <script>
        $(function() {
            $('[name="file"]').change(function() {
                $(this).parents('form').submit();
            });

            $('#users-list').DataTable();

            $(document).on('click', '.disable-user', function() {
                var id = $(this).data('id');
                var value = $(this).data('value');
                swal({
                    title: "Are you sure?",
                    text: `You really want to ${value == 'enabled' ? 'disabled' : 'enabled'} ?`,
                    type: "warning",
                    showCancelButton: true,
                    closeOnConfirm: false,
                }, function(isConfirm) {
                    if (isConfirm) {
                        $.ajax({
                            url: '<?php echo e(route("disable-user")); ?>',
                            method: 'post',
                            data: {
                                id: id,
                                disable_user: value,
                                _token: '<?php echo e(csrf_token()); ?>'
                            },
                            success: function(response) {
                                if(response.success){
                                    swal({
                                        title: "Success!",
                                        text: response.message,
                                        type: "success",
                                        showConfirmButton: false
                                    }) 

                                    setTimeout(() => {
                                        location.reload();
                                    }, 2000);
                                }
                            }
                        })
                    }
                });
            })
        })
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/users/index.blade.php ENDPATH**/ ?>