<div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    'alert',
    'alert-danger' => !empty($type) && $type == 'error',
    'alert-success' => empty($type) || $type == 'success',
]); ?>">
    <?php echo e($message); ?>

</div>
<?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/components/alert.blade.php ENDPATH**/ ?>