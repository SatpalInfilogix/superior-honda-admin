<nav class="pcoded-navbar">
    <div class="nav-list">
        <div class="pcoded-inner-navbar main-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view dashboard'])): ?>
                <div class="pcoded-navigation-label">Dashboard</div>
            <ul class="pcoded-item pcoded-left-item">
                <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => Request::is('dashboard')]); ?>">
                    <a href="<?php echo e(route('dashboard.index')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                            <i class="feather icon-home"></i>
                        </span>
                        <span class="pcoded-mtext">Dashboard</span>
                    </a>
                </li>
            </ul>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view customer inquiry', 'view invoice', 'view services'])): ?>
                <div class="pcoded-navigation-label">Sales</div>
            <?php endif; ?>
            <ul class="pcoded-item pcoded-left-item">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view customer inquiry')): ?>
                <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'active' => Request::is('customer-inquiry', 'customer-inquiry/create', 'customer-inquiry/*/edit'),
                ]); ?>">
                    <a href="<?php echo e(route('customer-inquiry.index')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                            <i class="ti-direction"></i>
                        </span>
                        <span class="pcoded-mtext">Customer Inquiry</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'pcoded-hasmenu',
                    'pcoded-trigger active' => Request::is(
                        'invoices',
                        'invoices/create',
                        'invoices/*/edit',
                        'services',
                        'services/create',
                        'services/*/edit'),
                ]); ?>">
                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                            <i class="fas fa-cube"></i>
                        </span>
                        <span class="pcoded-mtext">Manage Invoices</span>
                    </a>
                    <ul class="pcoded-submenu">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view invoice')): ?>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'active' => Request::is(
                                            'invoices',
                                            'invoices/*/view'),
                                    
                            ]); ?>">
                                <a href="<?php echo e(route('invoices.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-micon">
                                        <i class="feather icon-edit"></i>
                                    </span>
                                    <span class="pcoded-mtext">Invoices</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view services')): ?>
                            <li class="<?php echo e(Request::segment(1) == 'services' ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('services.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-micon">
                                        <i class="fas fa-cog"></i>
                                    </span>
                                    <span class="pcoded-mtext">Invoice Services</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>    
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view inquiry','view inspection','view bay','view product','view promotions','view promotions','view reports'])): ?>
                    <div class="pcoded-navigation-label">Operations</div>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view inquiry')): ?>
                    <li  class="<?php echo e(Request::segment(1) == 'inquiries' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('inquiries.index')); ?>" class="waves-effect waves-dark">
                            <span class="pcoded-micon">
                                <i class="ti-notepad"></i>
                            </span>
                            <span class="pcoded-mtext">Inquiries</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view inspection')): ?>
                    <li class="<?php echo e(Request::segment(1) == 'inspection' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('inspection.index')); ?>" class="waves-effect waves-dark">
                            <span class="pcoded-micon">
                                <i class="ti-write"></i>
                            </span>
                            <span class="pcoded-mtext">Inspection</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view bay')): ?>
                    <li  class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'active' => Request::is('bay', 'bay/create', 'bay/*/edit'),
                    ]); ?>">
                        <a href="<?php echo e(route('bay.index')); ?>" class="waves-effect waves-dark">
                            <span class="pcoded-micon">
                                <i class="ti-package"></i>
                            </span>
                            <span class="pcoded-mtext">Bay</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view product')): ?>
                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'pcoded-hasmenu',
                        'pcoded-trigger active' => Request::is(
                            'products',
                            'products/create',
                            'products/*/edit',
                            'product-categories',
                            'product-categories/create',
                            'product-categories/*/edit'),
                    ]); ?>">
                        <a href="javascript:void(0)" class="waves-effect waves-dark">
                            <span class="pcoded-micon">
                                <i class="fas fa-cube"></i>
                            </span>
                            <span class="pcoded-mtext">Manage Products</span>
                        </a>
						<ul class="pcoded-submenu">
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'active' => Request::is(
                                    'product-categories',
                                    'product-categories/create',
                                    'product-categories/*/edit'),
                            ]); ?>">
							    <a href="<?php echo e(route('product-categories.index')); ?>" class="waves-effect waves-dark">
									<span class="pcoded-micon">
										<i class="fas fa-cube"></i>
									</span>
									<span class="pcoded-mtext">Product Categories</span>
								</a>
							</li>
							<li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'active' => Request::is(
                                    'products',
                                    'products/create',
                                    'products/*/edit',),
                            ]); ?>">
							    <a href="<?php echo e(route('products.index')); ?>" class="waves-effect waves-dark">
									<span class="pcoded-micon">
										<i class="fas fa-cube"></i>
									</span>
									<span class="pcoded-mtext">Products</span>
								</a>
							</li>
						</ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view promotions')): ?>
                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'active' => Request::is(
                            'promotions',
                            'promotions/create',
                            'promotions/*/edit'),
                    ]); ?>">
                        <a href="<?php echo e(route('promotions.index')); ?>" class="waves-effect waves-dark">
                            <span class="pcoded-micon">
                                <i class="fas fa-credit-card"></i>
                            </span>
                            <span class="pcoded-mtext">Promotions</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view reports')): ?>
                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'active' => Request::is('reports'),
                    ]); ?>">
                        <a href="<?php echo e(route('reports.index')); ?>" class="waves-effect waves-dark">
                            <span class="pcoded-micon">
                                <i class="feather icon-user"></i>
                            </span>
                            <span class="pcoded-mtext">Reports</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view vehicle configuration',''])): ?>
                    <div class="pcoded-navigation-label">Configuration</div>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view vehicle configuration','view branch')): ?>
                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'pcoded-hasmenu',
                        'pcoded-trigger active' => Request::is(
                            'vehicle-categories',
                            'vehicle-categories/create',
                            'vehicle-categories/*/edit',
                            'vehicle-types',
                            'vehicle-types/create',
                            'vehicle-types/*/edit',
                            'vehicle-brands',
                            'vehicle-brands/create',
                            'vehicle-brands/*/edit',
                            'vehicle-models',
                            'vehicle-models/create',
                            'vehicle-models/*/edit',
                            'vehicle-model-variants',
                            'vehicle-model-variants/create',
                            'vehicle-model-variants/*/edit'),
                    ]); ?>">
                        <a href="javascript:void(0)" class="waves-effect waves-dark">
                            <span class="pcoded-micon"><i class="fas fa-car"></i></span>
                            <span class="pcoded-mtext">Vehicle Configuration</span>
                        </a>
                        <ul class="pcoded-submenu">
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'active' => Request::is(
                                    'vehicle-categories',
                                    'vehicle-categories/create',
                                    'vehicle-categories/*/edit'),
                            ]); ?>">
                                <a href="<?php echo e(route('vehicle-categories.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-mtext">Vehicle Categories</span>
                                </a>
                            </li>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'active' => Request::is(
                                    'vehicle-types',
                                    'vehicle-types/create',
                                    'vehicle-types/*/edit'),
                            ]); ?>">
                                <a href="<?php echo e(route('vehicle-types.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-mtext">Vehicle Types</span>
                                </a>
                            </li>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'active' => Request::is(
                                    'vehicle-brands',
                                    'vehicle-brands/create',
                                    'vehicle-brands/*/edit'),
                            ]); ?>">
                                <a href="<?php echo e(route('vehicle-brands.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-mtext">Vehicle Brands</span>
                                </a>
                            </li>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'active' => Request::is(
                                    'vehicle-models',
                                    'vehicle-models/create',
                                    'vehicle-models/*/edit'),
                            ]); ?>">
                                <a href="<?php echo e(route('vehicle-models.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-mtext">Vehicle Models</span>
                                </a>
                            </li>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'active' => Request::is(
                                    'vehicle-model-variants',
                                    'vehicle-model-variants/create',
                                    'vehicle-model-variants/*/edit'),
                            ]); ?>">
                                <a href="<?php echo e(route('vehicle-model-variants.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-mtext">Vehicle Model Variants</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view branch')): ?>
                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'pcoded-hasmenu',
                        'pcoded-trigger active' => Request::is(
                            'branches',
                            'branches/create',
                            'branches/*/edit',
                            'locations',
                            'locations/create',
                            'locations/*/edit'),
                    ]); ?>">
                        <a href="javascript:void(0)" class="waves-effect waves-dark">
                            <span class="pcoded-micon">
                                <i class="fas fa-cube"></i>
                            </span>
                            <span class="pcoded-mtext">Location Management</span>
                        </a>
                        <ul class="pcoded-submenu">
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'active' => Request::is(
                                    'locations',
                                    'locations/create',
                                    'locations/*/edit'),
                            ]); ?>">
                                <a href="<?php echo e(route('locations.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-micon">
                                        <i class="fas fa-cube"></i>
                                    </span>
                                    <span class="pcoded-mtext">Location Management</span>
                                </a>
                            </li>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'active' => Request::is(
                                    'branches',
                                    'branches/create',
                                    'branches/*/edit'),
                            ]); ?>">
                                <a href="<?php echo e(route('branches.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-micon">
                                        <i class="fas fa-cube"></i>
                                    </span>
                                    <span class="pcoded-mtext">Branch Management</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>

                

                <!-- <li class="<?php echo e(Request::segment(1) == 'banners' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('banners.index')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                            <i class="fas fa-cube"></i>
                        </span>
                        <span class="pcoded-mtext">Banners</span>
                    </a>
                </li> -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view user','view customer'])): ?>
                    <div class="pcoded-navigation-label">User management</div>
                <?php endif; ?>
                <ul class="pcoded-item pcoded-left-item">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view user')): ?>
                        <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'active' => Request::is('users', 'users/create', 'users/*/edit'),
                        ]); ?>">
                            <a href="<?php echo e(route('users.index')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-micon">
                                    <i class="feather icon-user"></i>
                                </span>
                                <span class="pcoded-mtext">User Management</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view customer')): ?>
                        <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'active' => Request::is('customers', 'customers/create', 'customers/*/edit'),
                        ]); ?>">
                            <a href="<?php echo e(route('customers.index')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-micon">
                                    <i class="feather icon-users"></i>
                                </span>
                                <span class="pcoded-mtext">Customer Management</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>

                

            </ul>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view job','view faqs','view testimonials','view roles & permissions','view settings'])): ?>
                <div class="pcoded-navigation-label">Settings</div>
            <?php endif; ?>
            <ul class="pcoded-item pcoded-left-item">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view job')): ?>
                    <li class="view email template ">
                        <a href="<?php echo e(route('emails.index')); ?>" class="waves-effect waves-dark">
                            <span class="pcoded-micon">
                                <i class="feather icon-mail"></i>
                            </span>
                            <span class="pcoded-mtext">Email Template</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view faqs')): ?>
                    <li class="<?php echo e(Request::segment(1) == 'faqs' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('faqs.index')); ?>" class="waves-effect waves-dark">
                            <span class="pcoded-micon">
                                <i class="fas fa-question-circle"></i>
                            </span>
                            <span class="pcoded-mtext">Faq</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view testimonials')): ?>
                    <li class="<?php echo e(Request::segment(1) == 'testimonials' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('testimonials.index')); ?>" class="waves-effect waves-dark">
                            <span class="pcoded-micon">
                                <i class="fas fa-quote-right"></i>
                            </span>
                            <span class="pcoded-mtext">Testimonials</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view roles & permissions')): ?>
                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'pcoded-hasmenu',
                        'pcoded-trigger active' => Request::is('roles', 'roles-and-permissions'),
                    ]); ?>">
                        <a href="javascript:void(0)" class="waves-effect waves-dark">
                            <span class="pcoded-micon"><i class="feather icon-clipboard"></i></span>
                            <span class="pcoded-mtext">Roles & Permissions</span>
                        </a>
                        <ul class="pcoded-submenu">
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => Request::is('roles')]); ?>">
                                <a href="<?php echo e(route('roles.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-mtext">Manage Roles</span>
                                </a>
                            </li>
                            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => Request::is('roles-and-permissions')]); ?>">
                                <a href="<?php echo e(route('roles-and-permissions.index')); ?>" class="waves-effect waves-dark">
                                    <span class="pcoded-mtext">Roles & Permissions</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view settings')): ?>
                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'active' => Request::is('settings', 'settings/general-setting'),
                    ]); ?>">
                        <a href="<?php echo e(route('settings.index')); ?>" class="waves-effect waves-dark">
                            <span class="pcoded-micon">
                                <i class="feather icon-settings"></i>
                            </span>
                            <span class="pcoded-mtext">Settings</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/layouts/components/sidebar.blade.php ENDPATH**/ ?>