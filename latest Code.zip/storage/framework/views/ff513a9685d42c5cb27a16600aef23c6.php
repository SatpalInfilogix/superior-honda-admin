

<?php $__env->startSection('content'); ?>
<style>
    .modal-content {
        width: 173%;
        margin-left: -104px;
    }
    .main-header {
        display: flex;
    }
    .header-left-section {
        float: left;
        margin: 0;
        padding: 0;
    }
    .header-right-section {
        float: right; 
        width: 249px;
        margin-top: 22px;
        margin-left: 20%;
    }
    .invoice-number-div {
        border: 1px solid;
        border-radius: 10px;
        width: 220px;
        height: 66px;
        display: flex;
        justify-content: space-between;
    }
    .estrick-ul-list {
        list-style-type: none; /* Remove default bullets */
    }
    .estrick-li-element::before {
        content: "* "; /* Add asterisk before each item */
    }
    .estrick-li-element {
        width: 166px;
    }
    .address-header {
        display: flex;
    }
    .content-section {
        display: flex;
    }
    .bill-to-section {
        float: left;
        margin-top: 44px;
    }
    .ship-to-section {
        float: right;
        margin-top: 44px;
    }
    .department-table {
        border: 1px solid;
        border-radius: 11px;
        width: 100%;
    }
    .item-table-heading {
        border: 1px solid;
        width: 100%;
    }
    .total-amount {
        font-size: 20px;
        font-weight: 800;
    }
</style>

<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>Invoices</h5>
                                <div class="float-right">
                                    <button id="print-btn" class="btn btn-primary btn-md primary-btn">Print</button>
                                    <a href="<?php echo e(route('invoices.create')); ?>" class="btn btn-primary btn-md primary-btn">Add Invoice</a>
                                </div>
                            </div>

                            <div class="card-block">
                                <div class="dt-responsive table-responsive">
                                    <form id="invoiceFilterForm" method="GET" action="<?php echo e(route('invoices.index')); ?>" class="mb-3">
                                        <div class="row mr-0">
                                            <div class="col-md-2">
                                                <input type="text" name="invoice_no" class="form-control" placeholder="Invoice Number" value="<?php echo e(request('invoice_no')); ?>">
                                            </div>
                                            <div class="col-md-2">
                                                <input type="text" id="userSearch" name="customer_name" class="form-control user-autocomplete" placeholder="Customer Name" value="<?php echo e(request('customer_name')); ?>">
                                                <div class="autocomplete-items"></div> 
                                            </div>
                                            <div class="col-md-2">
                                                <input type="text" name="mobile" class="form-control" placeholder="Mobile Number" value="<?php echo e(request('mobile')); ?>">
                                            </div>
                                            <div class="col-md-3">
                                                <input type="date" name="date" class="form-control" value="<?php echo e(request('date')); ?>">
                                            </div>
                                            <div class="col-md-3">
                                                <button type="submit" class="btn btn-primary primary-btn custom">Filter</button>
                                                <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-secondary custom">Reset</a>
                                            </div>
                                        </div>
                                    </form>
                                    
                                    <table id="invoice-list" class="table table-striped table-bordered nowrap">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Invoice Number</th>
                                                <th>Email</th>
                                                <th>Total Product</th>
                                                <th>Total Amount</th>
                                                <th>Invoice View</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($key + 1); ?></td>
                                                    <td><?php echo e($invoice->invoice_no); ?></td>
                                                    <td><?php echo e(optional($invoice->order)->email); ?></td>
                                                    <td><?php echo e($invoice->totalProducts); ?></td>
                                                    <td><?php echo e($invoice->totalAmount); ?></td>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <?php if($invoice->order_id == Null): ?>
                                                                <button type="button" class="btn btn-primary primary-btn waves-effect waves-light mr-2" data-toggle="modal" data-target="#invoiceModalJob<?php echo e($key); ?>">
                                                                    <i class="feather icon-eye m-0"></i>
                                                                </button>
                                                                <a href="<?php echo e(route('invoices.edit', $invoice->id)); ?>"
                                                                    class="btn btn-primary primary-btn waves-effect waves-light mr-2 edit-vehicle-type">
                                                                    <i class="feather icon-edit m-0"></i>
                                                                </a>
                                                                <button data-endpoint="<?php echo e(route('invoices.invoice-print', $invoice->id )); ?>" id="print-invoice"class="print-invoice btn btn-primary waves-effect waves-light mr-2 primary-btn"><i class="feather icon-printer m-0"></i></button>
                                                            <?php else: ?>
                                                                <button type="button" class="btn btn-primary primary-btn waves-effect waves-light mr-2" data-toggle="modal" data-target="#invoiceModalOrder<?php echo e($key); ?>">
                                                                    <i class="feather icon-eye m-0"></i>
                                                                </button>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (isset($component)) { $__componentOriginal5609eec52f8d452951cdd2468aad14ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5609eec52f8d452951cdd2468aad14ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.include-plugins','data' => ['dataTable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('include-plugins'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['dataTable' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $attributes = $__attributesOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $component = $__componentOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__componentOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>

<!-- Invoice Modals -->
<?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($invoice->order_id == Null): ?>
    <?php $productDeatils = json_decode($invoice->product_details); ?>
    <div class="modal fade" id="invoiceModalJob<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Invoice : <?php echo e($invoice->invoice_no); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table class="table table-striped table-bordered nowrap">
                        <tr>
                            <td>Sr.</td>
                            <td>Item</td>
                            <td>Price</td>
                            <td>Discount</td>
                            <td>Discount Price</td>
                        </tr>
                        <tbody>
                        <?php if($productDeatils): ?>
                            <?php $__currentLoopData = $productDeatils->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proKey => $productDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($proKey + 1); ?></td>
                                    <td><?php echo e($productDetail->product); ?></td>
                                    <td>$<?php echo e(number_format($productDetail->price, 2)); ?></td>
                                    <td><?php echo e(optional($productDetail)->discount); ?> %</td>
                                    <td>$<?php echo e(number_format(optional($productDetail)->discounted_price,2)); ?> </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <tbody>
                    </table>
                    <div class="float-right total-amount">Total Amount: $<?php echo e(number_format(optional($productDeatils)->totalAmount,2)); ?></div>
                </div>
                <div class="modal-footer d-flex">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="modal fade" id="invoiceModalOrder<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Invoice</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="header-right-section float-right">
                        <h5>Charge Invoice</h5>
                        <div class="invoice-number-div" style="display: flex;">
                            <p style="margin-top:20px; margin-left:5px;">Invoice# </p>
                            <p style="margin-top:20px; margin-right:5px;"><?php echo e($invoice->invoice_no); ?></p>
                        </div>
                    </div>
                    <section>
                        <div class="main-header">
                            <div class="header-left-section">
                                <h3>SUPERIOR PARTS LTD.</h3>
                                <p stalign="left" style="width:150%">Website:- https://hondasuperiorpart.com Email:- contact@hondasuperiorpart.com</p>
                            </div>
                        </div>
                        <div class="address-header">
                            <div class="address address-1">
                                <ul class="estrick-ul-list">
                                    <li class="estrick-li-element">
                                        88 Haglet Park Road
                                        Kingston 10, Jamaica
                                    </li>
                                    <li class="estrick-li-element">
                                        11 Caledonia Road
                                        Mandeville, Jamaica
                                        Tel:- 987446301
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </section>
                    <div class="bill-to-section">
                        <h5> Bill To </h5>
                        <p> <?php echo e(optional($invoice->billingAddress)['first_name'].' '. optional($invoice->billingAddress)['last_name']); ?>, <?php echo e(optional($invoice->billingAddress)['address']); ?>, <?php echo e(optional($invoice->billingAddress)['city']); ?></p>
                    </div>
                    <div class="ship-to-section">
                        <h5>Ship To </h5>
                        <p> <?php echo e(optional($invoice->shippingAddress)['first_name'].' '.optional($invoice->shippingAddress)['last_name']); ?>, <?php echo e(optional($invoice->shippingAddress)['address']); ?>, <?php echo e(optional($invoice->shippingAddress)['city']); ?></p>
                    </div>
                    <br><br><br><br><br><br><br>
                    <table class="department-table">
                        <tr>
                            <td>User ID: </td>
                            <td>RAD </td>
                            <td>S/Clerk: </td>
                            <td>HQ </td>
                            <td>Invoice Date: </td>
                            <td>May 29, 2024</td>
                            <td>Page# : 1 of 1</td>
                        </tr>
                        <tr>
                            <td>Bill By: </td>
                            <td>RL</td>
                            <td>Time</td>
                            <td>16:07:05</td>
                            <td>Transit#:  </td>
                            <td> </td>
                            <td>GCT# 541788</td>
                        </tr>
                    </table>
                    <table class="item-table-heading">
                        <tr>
                            <td>Cust ID: </td>
                            <td>Reference </td>
                            <td>P/O#: </td>
                            <td>Terms</td>
                        </tr>
                        <tr>
                            <td>Item</td>
                            <td>Description</td>
                            <td>Quantity</td>
                            <td>Price</td>
                            <td>Total</td>
                        </tr>
                        <?php if(isset($invoice->cart_items['products']) && is_array($invoice->cart_items['products'])): ?>
                            <?php $__currentLoopData = $invoice->cart_items['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($product['name']); ?></td>
                                    <td></td>
                                    <td><?php echo e($product['quantity']); ?> ea</td>
                                    <td>$<?php echo e(number_format($product['price'], 2)); ?></td>
                                    <td>$<?php echo e(number_format($product['price'], 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </table>
                    <br><br><br><hr>
                    <div style="float:left; width:70%">
                        <p>No Return after 24Hrs & On correct Items. Incorrect parts purchased must be in orignal Condition. A 10% restocking fee will apply. Electrical parts are not refundable. No refund without Invoice.</p>
                    </div>
                    <div class="float-right">
                        <p class="float-left"> NonTaxable Total &nbsp;&nbsp;</p><p class="float-right"><?php echo e(optional($invoice->cart_items)['formatted_sub_total']); ?></p><br>
                        <p class="float-left"> Disc% &nbsp;&nbsp;</p><p class="float-right"><?php echo e(optional(optional($invoice->cart_items)['applied_coupons'])['discount_amount']); ?></p><br>
                        <br>
                        <hr>
                        <p class="float-left">Sub-Total &nbsp;&nbsp;</p><p class="float-right"><?php echo e(optional($invoice->cart_items)['formatted_grand_total']); ?></p><br>
                        <p class="float-left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tax &nbsp;&nbsp;</p><p style="float:right"><?php echo e(( optional($invoice->cart_items)['grand_total']) * 0.18); ?></p><br>
                        <br><hr>
                        <p class="float-left">Total Amount &nbsp;&nbsp;</p><p style="float:right;font-weight: 5"><b><?php echo e(number_format( optional($invoice->cart_items)['grand_total'] + (optional($invoice->cart_items)['grand_total']* 0.18) , 2)); ?></b></p><br><br>
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-center">
                    <button type="button" class="btn btn-secondary pdf-import" data-id="<?php echo e($invoice->id); ?>" data-dismiss="modal">Download Invoice-PDF</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
       
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    document.getElementById('invoiceFilterForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent default form submission
        const form = event.target;
        const formData = new FormData(form);
        const queryParams = new URLSearchParams();
    
        formData.forEach((value, key) => {
            if (value.trim() !== '') {
                queryParams.append(key, value);
            }
        });
    
        window.location.href = form.action + '?' + queryParams.toString();
    });
    
    $(function() {
        $('#print-btn').click(function() {
            var printUrl = '<?php echo e(route('invoices.print-invoice')); ?>';
            var printWindow = window.open(printUrl, '_blank');

            printWindow.onload = function() {
                printWindow.print();
            };
        });

        $('.print-invoice').click(function() {
            var url = $(this).data('endpoint');
            var printWindow = window.open(url, '_blank');

            printWindow.onload = function() {
                printWindow.print();
            };
        });

        $('#invoice-list').DataTable();
        $('.pdf-import').on('click', function(){
             var invoiceId = $(this).data('id'); // Assuming the button has a data attribute with the invoice ID

            $.ajax({
                url: '<?php echo e(env("APP_URL")); ?>/download-invoice-pdf/' + invoiceId,
                type: 'GET',
                xhrFields: {
                    responseType: 'blob' // Important to handle the binary data
                },
                success: function(data, status, xhr) {
                    var filename = "";
                    var disposition = xhr.getResponseHeader('Content-Disposition');
                    if (disposition && disposition.indexOf('attachment') !== -1) {
                        var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                        var matches = filenameRegex.exec(disposition);
                        if (matches != null && matches[1]) filename = matches[1].replace(/['"]/g, '');
                    }
                    var blob = new Blob([data], { type: 'application/pdf' });
                    var link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = filename;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                },
                error: function(xhr, status, error) {
                    console.error('Error downloading invoice:', error);
                    alert('Failed to download invoice. Please try again.');
                }
            });
        });
    });
    $(document).ready(function () {
        $('body').on('input', '.user-autocomplete', function () {
            var input = $(this).val().trim();
            var autocompleteContainer = $(this).siblings('.autocomplete-items');

            $.ajax({
                type: 'GET',
                url: '<?php echo e(route('user.autocomplete')); ?>',
                data: { input: input },
                success: function (response) {
                    autocompleteContainer.empty();
                    if (response.length > 0) {
                        $.each(response, function (key, value) {
                            var autocompleteItem = '<div class="autocomplete-item" data-id="' + value.id + '">' + value.first_name +' '+value.last_name+'</div>';
                            autocompleteContainer.append(autocompleteItem);
                        });
                        autocompleteContainer.show();
                    } else {
                        autocompleteContainer.hide();
                    }
                },
                error: function (xhr, status, error) {
                    console.error('Autocomplete AJAX error:', status, error);
                }
            });
        });

        $('body').on('click', '.autocomplete-item', function() {
            var productName = $(this).text();
            var productId = $(this).data('id');
            $('#userSearch').val(productName);
            $(this).closest('.autocomplete-items').empty().hide();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/invoices/index.blade.php ENDPATH**/ ?>