

<?php $__env->startSection('content'); ?>
<style>
    span.ui-selectmenu-text {
    display: none;
}
    </style>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Edit Product</h5>
                                    <div class="float-right">
                                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary primary-btn btn-md">
                                            <i class="feather icon-arrow-left"></i>
                                            Go Back
                                        </a>
                                    </div>
                                </div>
                                <div class="card-block">
                                    <form action="<?php echo e(route('products.update',$product->id)); ?>" method="POST"  enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <!-- <div class="row">
                                            <div class="col-md-6 form-group">
                                                <label for="parent_category_id">Parent Category <span style="color: red;">*</span></label>
                                                <select id="parent_category_id" name="parent_category_id[]" class="form-control chosen-select" multiple="multiple">
                                                    <?php
                                                        $selected_categories = [];
                                                    ?>    
                                                    <?php $__currentLoopData = $product->parent_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            array_push($selected_categories, $parent_category->parent_category_name);
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="select_all">Select All</option>
                                                        <option value="product" <?php echo e(in_array('product', $selected_categories) ? 'selected' : ''); ?>>Product</option>
                                                        <option value="service" <?php echo e(in_array('service', $selected_categories) ? 'selected' : ''); ?>>Service</option>
                                                        <option value="accessories" <?php echo e(in_array('accessories', $selected_categories) ? 'selected' : ''); ?>>Accessories</option>
                                                </select>
                                                <span class="form-control-danger" id="parent_category_id_error" style="display:none; color: #dc3545; font-size:12px;">Please select atleast 1 category.</span>
                                            </div>
                                        </div> -->

                                        <div class="row">
                                            <div class="col-md-6 form-group">
                                                <label for="product_code">Product Code <span style="color: red;">*</span></label>
                                                <input class="form-control" id="product_code" name="product_code" label="Product Code"
                                                    value="<?php echo e(old('product_code', $product->product_code)); ?>"/>
                                            </div>

                                            <div class="col-md-6 form-group">
                                                <label for="category_id">Category <span style="color: red;">*</span></label>
                                                <select name="category_id" id="category_id" class="form-control">
                                                    <option value="" selected disabled>Select Category</option>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($category->id); ?>" <?php if($product->category_id == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 form-group">
                                                <?php if (isset($component)) { $__componentOriginal262894a2c291df91ae9f7b925bf8a923 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal262894a2c291df91ae9f7b925bf8a923 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-text','data' => ['name' => 'product_name','label' => 'Product Name','value' => ''.e(old('product_name', $product->product_name)).'','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'product_name','label' => 'Product Name','value' => ''.e(old('product_name', $product->product_name)).'','required' => 'true']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal262894a2c291df91ae9f7b925bf8a923)): ?>
<?php $attributes = $__attributesOriginal262894a2c291df91ae9f7b925bf8a923; ?>
<?php unset($__attributesOriginal262894a2c291df91ae9f7b925bf8a923); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal262894a2c291df91ae9f7b925bf8a923)): ?>
<?php $component = $__componentOriginal262894a2c291df91ae9f7b925bf8a923; ?>
<?php unset($__componentOriginal262894a2c291df91ae9f7b925bf8a923); ?>
<?php endif; ?>
                                            </div>

                                            <div class="col-md-6 form-group">
                                                <?php if (isset($component)) { $__componentOriginal262894a2c291df91ae9f7b925bf8a923 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal262894a2c291df91ae9f7b925bf8a923 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-text','data' => ['name' => 'manufacture_name','label' => 'Manufacture Name','value' => ''.e(old('manufacture_name', $product->manufacture_name)).'','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'manufacture_name','label' => 'Manufacture Name','value' => ''.e(old('manufacture_name', $product->manufacture_name)).'','required' => 'true']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal262894a2c291df91ae9f7b925bf8a923)): ?>
<?php $attributes = $__attributesOriginal262894a2c291df91ae9f7b925bf8a923; ?>
<?php unset($__attributesOriginal262894a2c291df91ae9f7b925bf8a923); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal262894a2c291df91ae9f7b925bf8a923)): ?>
<?php $component = $__componentOriginal262894a2c291df91ae9f7b925bf8a923; ?>
<?php unset($__componentOriginal262894a2c291df91ae9f7b925bf8a923); ?>
<?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 form-group">
                                            <label for="vehicle_category_id">Vehicle Category</label>
                                            <select name="vehicle_category_id" id="vehicle_category_id" class="form-control">
                                                <option value="" selected disabled>Select Vehicle Category</option>
                                                <?php $__currentLoopData = $vehicleCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicleCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($vehicleCategory->id); ?>" <?php if($product->vehicle_category_id == $vehicleCategory->id): echo 'selected'; endif; ?>><?php echo e($vehicleCategory->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label for="brand_name" class>Brand Name</label>
                                                <select class="form-control" id="brand_name" name="brand_name" placeholder="Select Brand">
                                                    <option value="" selected disabled>Select Brand</option>
                                                   <?php if($brands): ?>
                                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($brand->id); ?>" <?php if($product->brand_id == $brand->id): echo 'selected'; endif; ?>><?php echo e($brand->brand_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6 form-group">
                                                <label for="model" class>Model Name</label>
                                                <select class="form-control" id="model_name" name="model_name">
                                                    <option value="" selected disabled>Select Model</option>
                                                    <?php if($vehicleModels): ?>
                                                        <?php $__currentLoopData = $vehicleModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicleModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($vehicleModel->id); ?>" <?php if($product->model_id == $vehicleModel->id): echo 'selected'; endif; ?>><?php echo e($vehicleModel->model_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>

                                            <div class="col-md-6 form-group">
                                                <label for="model_variant_name" class>Model Variant Name</label>
                                                <select class="form-control" id="model_variant_name" name="model_variant_name">
                                                    <option value="" selected disabled>Select Model Variant Name</option>
                                                    <?php if($modelVariants): ?>
                                                    <?php $__currentLoopData = $modelVariants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelVariants): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($modelVariants->id); ?>" <?php if($product->varient_model_id == $modelVariants->id): echo 'selected'; endif; ?>><?php echo e($modelVariants->variant_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 form-group">
                                                <label for="model_name" class>Vehicle Type</label>
                                                <select class="form-control" id="vehicle_type" name="vehicle_type">
                                                    <option value="" selected disabled>Select Vehicle Type</option>
                                                    <?php if($vehicleTypes): ?>
                                                    <?php $__currentLoopData = $vehicleTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicleType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($vehicleType->id); ?>" <?php if($product->type_id == $vehicleType->id): echo 'selected'; endif; ?>><?php echo e($vehicleType->vehicle_type); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                </select>
                                            </div>

                                            <div class="col-md-6 form-group">
                                                <?php if (isset($component)) { $__componentOriginal262894a2c291df91ae9f7b925bf8a923 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal262894a2c291df91ae9f7b925bf8a923 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-text','data' => ['name' => 'supplier','label' => 'Supplier','value' => ''.e(old('supplier', $product->supplier)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'supplier','label' => 'Supplier','value' => ''.e(old('supplier', $product->supplier)).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal262894a2c291df91ae9f7b925bf8a923)): ?>
<?php $attributes = $__attributesOriginal262894a2c291df91ae9f7b925bf8a923; ?>
<?php unset($__attributesOriginal262894a2c291df91ae9f7b925bf8a923); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal262894a2c291df91ae9f7b925bf8a923)): ?>
<?php $component = $__componentOriginal262894a2c291df91ae9f7b925bf8a923; ?>
<?php unset($__componentOriginal262894a2c291df91ae9f7b925bf8a923); ?>
<?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6 form-group">
                                                <label for="cost_price" class>Cost Price</label>
                                                <input type="number" id="price" name="cost_price" class="form-control"value="<?php echo e(old('cost_price', $product->cost_price)); ?>">
                                            </div>

                                            <div class="col-md-6 form-group">
                                                <label for="item_number" class>Item Number</label>
                                                <input type="number" id="item_number" name="item_number" class="form-control"value="<?php echo e(old('item_number', $product->item_number)); ?>">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6 form-group">
                                                <label for="model_name" class>Quantity</label>
                                                <input type="number" id="quantity" name="quantity" class="form-control"value="<?php echo e(old('quantity', $product->quantity)); ?>">
                                            </div>

                                            <div class="col-md-6 form-group">
                                                <label for="year">Year</label>
                                                <select id="year_range" name="year_range[]" class="form-control chosen-select" multiple="multiple">
                                                    <option value="select_all">Select All</option>
                                                    <?php $__currentLoopData = range(date('Y'),1950); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($year); ?>" 
                                                            <?php if(in_array($year, old('year_range', $selectedYears))): ?> selected <?php endif; ?>>
                                                            <?php echo e($year); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-3 form-group">
                                                <input type="checkbox" id="oem" name="oem" value="<?php echo e($product->is_oem); ?>" <?php if($product->is_oem == 1): echo 'checked'; endif; ?> onclick='oemClick(this);'>
                                                <label for="oem" class>OEM</label>
                                            </div>
                                            <div class="col-md-3 form-group">
                                                <input type="checkbox" id="out_of_stock" name="out_of_stock" value="<?php echo e($product->out_of_stock); ?>" <?php if($product->out_of_stock == 1): echo 'checked'; endif; ?> onclick='outOfStock(this);'>
                                                <label for="out_of_stock" class>Out Of Stock</label>
                                            </div>
                                            <div class="col-md-3 form-group">
                                                <input type="checkbox" id="is_popular" name="is_popular" value="<?php echo e($product->popular); ?>" <?php if($product->popular == 1): echo 'checked'; endif; ?> onclick='popularClick(this);'>
                                                <label for="is_popular" class>Is Popular Product</label>
                                           </div>
                                           <div class="col-md-3 form-group">
                                               <input type="checkbox" id="used_part" name="used_part" value="<?php echo e($product->used_part); ?>" <?php if($product->used_part == 1): echo 'checked'; endif; ?> onclick='usedPart(this);'>
                                                <label for="used_part" class>Used Part</label>
                                            </div>
                                        </div>

                                        <div class ="row">
                                            <div class="col-md-3 form-group">
                                                <input type="checkbox" id="access_series" name="access_series" value="<?php echo e($product->access_series); ?>" <?php if($product->access_series == 1): echo 'checked'; endif; ?>  onclick='accessSeries(this);'>
                                                <label for="access_series" class>Accesseries</label>
                                            </div>
                                            <div class="col-md-3 form-group">
                                                <input type="checkbox" id="is_service" name="is_service" value="<?php echo e($product->is_service); ?>" <?php if($product->is_service == 1): echo 'checked'; endif; ?> onclick='serviceClick(this);'>
                                                <label for="is_service" class>Is Service</label>
                                             </div>
                                        </div>

                                          <div id="serviceFields" style="display: none;">
                                            <div class="row">
                                                <div class="col-md-6 form-group">
                                                    <label for="add-icon">Service Icon</label>
                                                    <div class="custom-file">
                                                        <input type="file" name="service_icon" class="custom-file-input" id="add-icon">
                                                        <label class="custom-file-label" for="add-icon">Choose Service Icon</label>
                                                        <div id="iconPreview">
                                                            <?php if($product->service_icon): ?>
                                                                <img src="<?php echo e(asset($product->service_icon)); ?>" id="preview-icon" class="icon-preview" width="50" height="50">
                                                            <?php else: ?>
                                                                <img src="" id="preview-icon" height="50" width="50" name="image" hidden>
                                                            <?php endif; ?>
                                                            </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 form-group">
                                                    <label for="short_description" class>Short Description</label>
                                                    <textarea id="short_description" name="short_description" class="form-control" rows="2" cols="50"><?php echo e(old('short_description', $product->short_description)); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12 form-group">
                                                <label for="branch">Description</label>
                                                <textarea id="description" name="description" class="form-control" rows="2" cols="50"><?php echo e(old('description', $product->description)); ?></textarea>
                                            </div>
                                        </div>

                                        <div class="position-relative form-group">
                                            <label for="inputLastname" class="">Image <span style="color: red;">*</span></label>
                                            <input type="file" name="images[]" id="images" accept="image/*" multiple class="form-control mb-1">
                                        </div>
                        
                                        <div class="row">
                                            <div class="col-md-12 form-group">
                                                <div id="image_preview" class="row">
                                                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="existing-img-div img-div" id="existing-img-div<?php echo e($image->id); ?>">
                                                            <img src="<?php echo e(asset($image->images)); ?>" id="previewImg-<?php echo e($image->id); ?>" style="height:141px; width:150px;" name="image" class="img-responsive image">
                                                            <div class='middle'>
                                                                <a href ="javascript:void(0)" class="btn btn-danger delete-image image-delete-<?php echo e($image->id); ?>" data-id="<?php echo e($image->id); ?>" id="delete-image"><i class="fas fa-trash"></i></a>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <span id="image_preview_new"></span>
                                                </div>
                                            </div>
                                            <input type ="hidden" name="image_id[]" id ="image_id">
                                        </div>

                                        <button type="submit" class="btn btn-primary primary-btn">Save</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal5609eec52f8d452951cdd2468aad14ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5609eec52f8d452951cdd2468aad14ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.include-plugins','data' => ['multipleImage' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('include-plugins'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['multipleImage' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $attributes = $__attributesOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__attributesOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5609eec52f8d452951cdd2468aad14ee)): ?>
<?php $component = $__componentOriginal5609eec52f8d452951cdd2468aad14ee; ?>
<?php unset($__componentOriginal5609eec52f8d452951cdd2468aad14ee); ?>
<?php endif; ?>

    <script>
         $(document).ready(function() {
            var startYear = 1950;
            var endYear = new Date().getFullYear();

            var yearDropdown = $('#year_range');
            for (var year = endYear; year >= startYear; year--) {
                yearDropdown.append($('<option>', {
                    value: year,
                    text: year
                }));
            }

            $(".chosen-select").chosen({
                width: '100%',
                no_results_text: "Oops, nothing found!"
            })

            $('#year_range').selectmenu();
        });

         document.addEventListener('DOMContentLoaded', function () {
            ClassicEditor
                .create(document.querySelector('#description'))
                .catch(error => {
                    console.error(error);
                });
        });

        let deletedImageId= [];
        $('.delete-image').on('click', function() {
            var imageId = $(this).data('id');
            deletedImageId.push(imageId);
            $('#previewImg-' + imageId).prop('hidden', true)
            $('.image-delete-' + imageId).prop('hidden', true)
            $('#existing-img-div' + imageId).prop('hidden', true)
            $('#image_id').val(deletedImageId);
        });

        function oemClick(e) {
            e.value = e.checked ? 1 : 0;
            $('#oem').val(e.value);
        }

        function serviceClick(e) {
            e.value = e.checked ? 1 : 0;
            $('#is_service').val(e.value);
            $('#serviceFields').toggle(e.checked);
            if (e.checked) {
                $('#access_series').prop('checked', false).val(0); 
            }
        }

        $(document).ready(function() {
            serviceClick(document.getElementById('is_service'));
        });

        function popularClick(e) {
            e.value = e.checked ? 1 : 0;
            $('#is_popular').val(e.value);
        }

        function outOfStock(e) {
            e.value = e.checked ? 1 : 0;
            $('#out_of_stock').val(e.value);
        }

        function usedPart(e) {
            e.value = e.checked ? 1 : 0;
            $('#used_part').val(e.value);
        }

        function accessSeries(e) {
            e.value = e.checked ? 1 : 0;
            $('#access_series').val(e.value);
            if (e.checked) {
                $('#is_service').prop('checked', false).val(0); // Uncheck and set value to 0
                $('#serviceFields').hide();
            }
        }

        $(function() {
            $('form').validate({
                rules: {
                    product_code: "required",
                    category_id: "required",
                    product_name: "required",
                    manufacture_name: "required",
                    vehicle_category_id: "required",
                    short_description: {
                        required: function() {
                            return $('#is_service').is(':checked');
                        }
                    },
                },
                messages: {
                    product_code: "Please enter product code",
                    category_id: "Please enter category name",
                    product_name: "Please enter product name",
                    manufacture_name: "Please enter manufacture name",
                    vehicle_category_id: "Please enter vehicle category",
                    short_description: "Please enter a short description",
                },
                errorClass: "text-danger f-12",
                errorElement: "span",
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass("form-control-danger");
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass("form-control-danger");
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
            $('#add-icon').change(function() {
                var file = this.files[0];
                if (file) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#iconPreview').html(
                            '<img class="preview-img" width="50px" height="50px" src="' + e.target
                            .result + '" alt="Selected Image">');
                    }
                    reader.readAsDataURL(file);
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Clients Data\Anurag\Projects\superior-honda-admin\resources\views/products/edit.blade.php ENDPATH**/ ?>